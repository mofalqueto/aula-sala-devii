<script setup>
  import RegisterUser from './components/registerUser.vue';
  import SelectUser from './components/selectUser.vue';
  import DeleteUser from './components/deleteUser.vue';
  import ModifyUser from './components/modifyUser.vue';
</script>

<template>
  <RegisterUser>

  </RegisterUser>

  <SelectUser>
    
  </SelectUser>

  <DeleteUser>

  </DeleteUser>

  <ModifyUser>

  </ModifyUser>
</template>

<style scoped>

</style>
